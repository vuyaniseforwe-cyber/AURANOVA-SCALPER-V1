//+------------------------------------------------------------------+
//| AURANOVA SCALPER V1 - MT4                                       |
//| Educational starter EA. Test thoroughly before any live trading. |
//+------------------------------------------------------------------+
#property strict
#property version   "1.00"
#property description "AURANOVA SCALPER V1 - EMA/RSI/ATR risk-managed Forex EA"

input int    FastEMA = 9;
input int    SlowEMA = 21;
input int    RSIPeriod = 14;
input double BuyRSIMin = 52.0;
input double SellRSIMax = 48.0;
input int    ATRPeriod = 14;
input double StopATRMultiplier = 1.5;
input double RewardRiskRatio = 1.2;
input double RiskPercent = 0.25;          // percent of equity at risk per trade
input double MaxDailyLossPercent = 2.0;   // blocks new trades after this day's equity loss
input int    MaxSpreadPoints = 20;        // broker points, not pips
input int    SlippagePoints = 10;
input int    MagicNumber = 261101;
input bool   AllowBuy = true;
input bool   AllowSell = true;

datetime lastBarTime = 0;
int dayKey = -1;
double dayStartEquity = 0.0;
bool dailyLock = false;

int DateKey(datetime t) { return TimeYear(t)*10000 + TimeMonth(t)*100 + TimeDay(t); }

void RefreshDailyGuard() {
   int today = DateKey(TimeCurrent());
   if(today != dayKey) {
      dayKey = today;
      dayStartEquity = AccountEquity();
      dailyLock = false;
   }
   if(dayStartEquity > 0 && AccountEquity() <= dayStartEquity*(1.0-MaxDailyLossPercent/100.0))
      dailyLock = true;
}

bool IsNewBar() {
   datetime t = iTime(Symbol(), Period(), 0);
   if(t != lastBarTime) { lastBarTime = t; return true; }
   return false;
}

int OpenPositionsForThisEA() {
   int count=0;
   for(int i=OrdersTotal()-1; i>=0; i--) {
      if(OrderSelect(i, SELECT_BY_POS, MODE_TRADES))
         if(OrderSymbol()==Symbol() && OrderMagicNumber()==MagicNumber &&
            (OrderType()==OP_BUY || OrderType()==OP_SELL)) count++;
   }
   return count;
}

double NormalizeLots(double lots) {
   double minLot=MarketInfo(Symbol(), MODE_MINLOT);
   double maxLot=MarketInfo(Symbol(), MODE_MAXLOT);
   double step=MarketInfo(Symbol(), MODE_LOTSTEP);
   if(step<=0) return 0;
   lots=MathMin(maxLot, MathMax(minLot, lots));
   lots=MathFloor(lots/step)*step;
   return NormalizeDouble(lots, 2);
}

double LotsForRisk(double stopDistancePrice) {
   if(stopDistancePrice<=0) return 0;
   double tickValue=MarketInfo(Symbol(), MODE_TICKVALUE);
   double tickSize=MarketInfo(Symbol(), MODE_TICKSIZE);
   if(tickValue<=0 || tickSize<=0) return 0;
   double riskMoney=AccountEquity()*RiskPercent/100.0;
   double lossPerLot=(stopDistancePrice/tickSize)*tickValue;
   if(lossPerLot<=0) return 0;
   double rawLots=riskMoney/lossPerLot;
   double minLot=MarketInfo(Symbol(), MODE_MINLOT);
   // Do not force minimum lot if it would exceed the intended risk.
   if(rawLots < minLot) return 0;
   return NormalizeLots(rawLots);
}

bool SendTrade(int type, double atr) {
   double stopDistance=atr*StopATRMultiplier;
   double minStop=(MarketInfo(Symbol(), MODE_STOPLEVEL)+2)*Point;
   if(stopDistance<minStop) stopDistance=minStop;
   double lots=LotsForRisk(stopDistance);
   if(lots<=0) { Print("AURANOVA: lot size is below broker minimum or risk data unavailable; no trade."); return false; }

   RefreshRates();
   double price=(type==OP_BUY)?Ask:Bid;
   double sl=(type==OP_BUY)?price-stopDistance:price+stopDistance;
   double tp=(type==OP_BUY)?price+stopDistance*RewardRiskRatio:price-stopDistance*RewardRiskRatio;
   price=NormalizeDouble(price, Digits);
   sl=NormalizeDouble(sl, Digits);
   tp=NormalizeDouble(tp, Digits);
   ResetLastError();
   int ticket=OrderSend(Symbol(), type, lots, price, SlippagePoints, sl, tp,
                        "AURANOVA SCALPER V1", MagicNumber, 0,
                        (type==OP_BUY)?clrDodgerBlue:clrTomato);
   if(ticket<0) { Print("AURANOVA: OrderSend failed. Error=", GetLastError()); return false; }
   Print("AURANOVA: trade opened. Ticket=", ticket, " lots=", lots);
   return true;
}

int OnInit() {
   lastBarTime=0;
   dayKey=-1;
   RefreshDailyGuard();
   Print("AURANOVA SCALPER V1 MT4 initialized on ", Symbol(), " timeframe ", Period());
   return(INIT_SUCCEEDED);
}

void OnTick() {
   RefreshDailyGuard();
   if(dailyLock) return;
   if(!IsNewBar()) return;
   if(!IsTradeAllowed()) return;
   if(MarketInfo(Symbol(), MODE_SPREAD)>MaxSpreadPoints) return;
   if(OpenPositionsForThisEA()>0) return;
   if(iBars(Symbol(), Period()) < SlowEMA+ATRPeriod+10) return;

   // Use closed candles (shift 1 and 2) to avoid signals changing mid-candle.
   double fast1=iMA(Symbol(),Period(),FastEMA,0,MODE_EMA,PRICE_CLOSE,1);
   double fast2=iMA(Symbol(),Period(),FastEMA,0,MODE_EMA,PRICE_CLOSE,2);
   double slow1=iMA(Symbol(),Period(),SlowEMA,0,MODE_EMA,PRICE_CLOSE,1);
   double slow2=iMA(Symbol(),Period(),SlowEMA,0,MODE_EMA,PRICE_CLOSE,2);
   double rsi=iRSI(Symbol(),Period(),RSIPeriod,PRICE_CLOSE,1);
   double atr=iATR(Symbol(),Period(),ATRPeriod,1);
   if(atr<=0) return;

   bool buySignal=(fast2<=slow2 && fast1>slow1 && rsi>=BuyRSIMin);
   bool sellSignal=(fast2>=slow2 && fast1<slow1 && rsi<=SellRSIMax);
   if(buySignal && AllowBuy) SendTrade(OP_BUY,atr);
   else if(sellSignal && AllowSell) SendTrade(OP_SELL,atr);
}
