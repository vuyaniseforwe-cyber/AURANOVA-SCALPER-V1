//+------------------------------------------------------------------+
//| AURANOVA SCALPER V1 - MT5                                       |
//| Educational starter EA. Test thoroughly before any live trading. |
//+------------------------------------------------------------------+
#property strict
#property version   "1.00"
#property description "AURANOVA SCALPER V1 - EMA/RSI/ATR risk-managed Forex EA"

#include <Trade/Trade.mqh>
CTrade trade;

input int    FastEMA = 9;
input int    SlowEMA = 21;
input int    RSIPeriod = 14;
input double BuyRSIMin = 52.0;
input double SellRSIMax = 48.0;
input int    ATRPeriod = 14;
input double StopATRMultiplier = 1.5;
input double RewardRiskRatio = 1.2;
input double RiskPercent = 0.25;          // percent of equity at risk per trade
input double MaxDailyLossPercent = 2.0;   // blocks new trades after this day's equity loss
input int    MaxSpreadPoints = 20;        // broker points, not pips
input ulong  MagicNumber = 261101;
input bool   AllowBuy = true;
input bool   AllowSell = true;

int fastHandle=INVALID_HANDLE, slowHandle=INVALID_HANDLE, rsiHandle=INVALID_HANDLE, atrHandle=INVALID_HANDLE;
datetime lastBarTime=0;
int dayKey=-1;
double dayStartEquity=0.0;
bool dailyLock=false;

int DateKey(datetime t) {
   MqlDateTime d; TimeToStruct(t,d);
   return d.year*10000+d.mon*100+d.day;
}

void RefreshDailyGuard() {
   int today=DateKey(TimeCurrent());
   if(today!=dayKey) {
      dayKey=today;
      dayStartEquity=AccountInfoDouble(ACCOUNT_EQUITY);
      dailyLock=false;
   }
   double equity=AccountInfoDouble(ACCOUNT_EQUITY);
   if(dayStartEquity>0 && equity<=dayStartEquity*(1.0-MaxDailyLossPercent/100.0))
      dailyLock=true;
}

bool IsNewBar() {
   datetime t=iTime(_Symbol,_Period,0);
   if(t!=lastBarTime) { lastBarTime=t; return true; }
   return false;
}

bool ReadBufferValue(int handle, int shift, double &value) {
   double values[];
   ArraySetAsSeries(values,true);
   if(CopyBuffer(handle,0,shift,1,values)!=1) return false;
   value=values[0];
   return true;
}

double NormalizeVolumeDown(double volume) {
   double minVol=SymbolInfoDouble(_Symbol,SYMBOL_VOLUME_MIN);
   double maxVol=SymbolInfoDouble(_Symbol,SYMBOL_VOLUME_MAX);
   double step=SymbolInfoDouble(_Symbol,SYMBOL_VOLUME_STEP);
   if(step<=0 || volume<minVol) return 0.0;
   volume=MathMin(maxVol,volume);
   volume=MathFloor(volume/step)*step;
   int digits=2;
   if(step>=1.0) digits=0;
   else if(step>=0.1) digits=1;
   else if(step>=0.01) digits=2;
   else digits=3;
   return NormalizeDouble(volume,digits);
}

double LotsForRisk(double stopDistancePrice, ENUM_ORDER_TYPE orderType, double entryPrice, double stopPrice) {
   double equity=AccountInfoDouble(ACCOUNT_EQUITY);
   double riskMoney=equity*RiskPercent/100.0;
   double lossPerLot=0.0;
   if(!OrderCalcProfit(orderType,_Symbol,1.0,entryPrice,stopPrice,lossPerLot)) return 0.0;
   lossPerLot=MathAbs(lossPerLot);
   if(lossPerLot<=0) return 0.0;
   double rawLots=riskMoney/lossPerLot;
   return NormalizeVolumeDown(rawLots);
}

bool HasPositionForThisEA() {
   for(int i=PositionsTotal()-1;i>=0;i--) {
      ulong ticket=PositionGetTicket(i);
      if(ticket>0 && PositionSelectByTicket(ticket)) {
         if(PositionGetString(POSITION_SYMBOL)==_Symbol &&
            (ulong)PositionGetInteger(POSITION_MAGIC)==MagicNumber) return true;
      }
   }
   return false;
}

bool SendTrade(ENUM_ORDER_TYPE type, double atr) {
   MqlTick tick;
   if(!SymbolInfoTick(_Symbol,tick)) return false;
   double point=SymbolInfoDouble(_Symbol,SYMBOL_POINT);
   int digits=(int)SymbolInfoInteger(_Symbol,SYMBOL_DIGITS);
   long stopsLevel=SymbolInfoInteger(_Symbol,SYMBOL_TRADE_STOPS_LEVEL);
   double stopDistance=MathMax(atr*StopATRMultiplier,(stopsLevel+2)*point);
   double entry=(type==ORDER_TYPE_BUY)?tick.ask:tick.bid;
   double sl=(type==ORDER_TYPE_BUY)?entry-stopDistance:entry+stopDistance;
   double tp=(type==ORDER_TYPE_BUY)?entry+stopDistance*RewardRiskRatio:entry-stopDistance*RewardRiskRatio;
   sl=NormalizeDouble(sl,digits);
   tp=NormalizeDouble(tp,digits);
   double lots=LotsForRisk(stopDistance,type,entry,sl);
   if(lots<=0) { Print("AURANOVA: calculated volume below broker minimum or risk calculation unavailable; no trade."); return false; }

   trade.SetExpertMagicNumber(MagicNumber);
   trade.SetDeviationInPoints(10);
   bool ok=false;
   if(type==ORDER_TYPE_BUY) ok=trade.Buy(lots,_Symbol,0.0,sl,tp,"AURANOVA SCALPER V1");
   else ok=trade.Sell(lots,_Symbol,0.0,sl,tp,"AURANOVA SCALPER V1");
   if(!ok) Print("AURANOVA: order failed. Retcode=",trade.ResultRetcode()," ",trade.ResultRetcodeDescription());
   else Print("AURANOVA: trade opened. Volume=",lots);
   return ok;
}

int OnInit() {
   if(FastEMA<1 || SlowEMA<2 || FastEMA>=SlowEMA || RiskPercent<=0 || MaxDailyLossPercent<=0 ||
      StopATRMultiplier<=0 || RewardRiskRatio<=0) return INIT_PARAMETERS_INCORRECT;
   fastHandle=iMA(_Symbol,_Period,FastEMA,0,MODE_EMA,PRICE_CLOSE);
   slowHandle=iMA(_Symbol,_Period,SlowEMA,0,MODE_EMA,PRICE_CLOSE);
   rsiHandle=iRSI(_Symbol,_Period,RSIPeriod,PRICE_CLOSE);
   atrHandle=iATR(_Symbol,_Period,ATRPeriod);
   if(fastHandle==INVALID_HANDLE || slowHandle==INVALID_HANDLE || rsiHandle==INVALID_HANDLE || atrHandle==INVALID_HANDLE)
      return INIT_FAILED;
   trade.SetExpertMagicNumber(MagicNumber);
   RefreshDailyGuard();
   Print("AURANOVA SCALPER V1 MT5 initialized on ",_Symbol," timeframe ",EnumToString(_Period));
   return INIT_SUCCEEDED;
}

void OnDeinit(const int reason) {
   if(fastHandle!=INVALID_HANDLE) IndicatorRelease(fastHandle);
   if(slowHandle!=INVALID_HANDLE) IndicatorRelease(slowHandle);
   if(rsiHandle!=INVALID_HANDLE) IndicatorRelease(rsiHandle);
   if(atrHandle!=INVALID_HANDLE) IndicatorRelease(atrHandle);
}

void OnTick() {
   RefreshDailyGuard();
   if(dailyLock || !IsNewBar()) return;
   if(!TerminalInfoInteger(TERMINAL_TRADE_ALLOWED) || !MQLInfoInteger(MQL_TRADE_ALLOWED)) return;
   MqlTick tick;
   if(!SymbolInfoTick(_Symbol,tick)) return;
   double point=SymbolInfoDouble(_Symbol,SYMBOL_POINT);
   if(point<=0 || (tick.ask-tick.bid)/point>MaxSpreadPoints) return;
   if(HasPositionForThisEA()) return;
   if(Bars(_Symbol,_Period)<SlowEMA+ATRPeriod+10) return;

   double fast1,fast2,slow1,slow2,rsi,atr;
   if(!ReadBufferValue(fastHandle,1,fast1) || !ReadBufferValue(fastHandle,2,fast2) ||
      !ReadBufferValue(slowHandle,1,slow1) || !ReadBufferValue(slowHandle,2,slow2) ||
      !ReadBufferValue(rsiHandle,1,rsi) || !ReadBufferValue(atrHandle,1,atr) || atr<=0) return;

   bool buySignal=(fast2<=slow2 && fast1>slow1 && rsi>=BuyRSIMin);
   bool sellSignal=(fast2>=slow2 && fast1<slow1 && rsi<=SellRSIMax);
   if(buySignal && AllowBuy) SendTrade(ORDER_TYPE_BUY,atr);
   else if(sellSignal && AllowSell) SendTrade(ORDER_TYPE_SELL,atr);
}
